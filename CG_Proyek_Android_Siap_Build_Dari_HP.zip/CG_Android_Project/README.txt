CG – CATATAN GAJI | PROYEK ANDROID

Proyek ini adalah source project Android Studio, bukan file APK siap instal.

FITUR
- Catatan ngelicin baju dewasa (Rp2.000/baju) dan anak (Rp1.500/baju)
- Tanggal input dibatasi 1 Jan 2025 sampai 31 Mar 2027
- Hitung pendapatan otomatis
- Riwayat, edit, hapus, laporan bulanan/tahunan
- Ekspor CSV (perlu diuji pada perangkat)
- Data disimpan lokal di perangkat melalui WebView localStorage

PENGGUNAAN OFFLINE
- Halaman aplikasi dimuat dari file lokal di dalam APK. Tidak perlu internet untuk membuka dan mencatat data.
- Data tersimpan di HP masing-masing. Data tidak otomatis terkirim atau tersinkron ke HP orang lain.
- Jangan hapus data aplikasi sebelum mengekspor/mencadangkan data.

MEMBUAT APK DENGAN ANDROID STUDIO
1. Ekstrak ZIP ini.
2. Buka Android Studio, pilih Open, lalu pilih folder CG_Android_Project.
3. Tunggu Gradle Sync. Pastikan Android SDK Platform 35 terpasang.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug berada di app/build/outputs/apk/debug/app-debug.apk.

MEMBAGIKAN APK
- Kirim app-debug.apk melalui WhatsApp, Bluetooth, Drive, atau cara berbagi file lainnya.
- Penerima mengunduh APK lalu mengizinkan pemasangan dari sumber tersebut jika Android memintanya.
- Untuk distribusi lebih luas, buat signed release APK melalui Build > Generate Signed Bundle / APK. Simpan keystore dengan aman.

CATATAN
- Perbaikan package MainActivity telah diselaraskan dengan namespace aplikasi.
- APK debug cocok untuk uji coba. Untuk distribusi resmi, gunakan signed release APK.

BUILD APK TANPA KOMPUTER (GITHUB ACTIONS)
1. Buat repository baru di GitHub melalui browser HP.
2. Upload SEMUA ISI folder CG_Android_Project ke repository (termasuk folder tersembunyi .github).
3. Buka tab Actions pada repository dan pilih workflow "Build CG Catatan Gaji APK".
4. Tekan Run workflow, lalu Run workflow lagi untuk memulai.
5. Tunggu sampai proses selesai dengan tanda hijau.
6. Buka hasil proses tersebut dan unduh artifact bernama CG-Catatan-Gaji-debug-APK.
7. Ekstrak ZIP artifact; di dalamnya ada app-debug.apk.

Catatan: Workflow membutuhkan koneksi internet saat build. APK yang dihasilkan dirancang untuk menjalankan halaman dan penyimpanan lokal; penggunaan aplikasi setelah terpasang dapat dilakukan offline. Ini adalah APK debug untuk uji coba, bukan signed release untuk distribusi resmi.
